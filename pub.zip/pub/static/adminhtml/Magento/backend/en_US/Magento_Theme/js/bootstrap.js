/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

require([
    'jquery/fileUploader/jquery.fileupload-ui',
    'mage/adminhtml/browser',
    'Magento_Theme/js/form'
]);
